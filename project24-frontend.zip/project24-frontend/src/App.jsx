import HashGenerator from "./components/HashGenerator";
import RuleDesigner from "./components/RuleDesigner";
import HashcatRunner from "./components/HashcatRunner";
import ResultsViewer from "./components/ResultsViewer";

export default function App() {
  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>🔐 Advanced Password Cracking Analysis Lab</h1>
      <p>
        <i>Educational & Controlled Environment</i>
      </p>

      <HashGenerator />
      <RuleDesigner />
      <HashcatRunner />
      <ResultsViewer />
    </div>
  );
}
