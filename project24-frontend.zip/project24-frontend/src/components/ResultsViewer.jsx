import { useEffect, useState } from "react";
import api from "../services/api";

export default function ResultsViewer() {
  const [results, setResults] = useState([]);

  useEffect(() => {
    api.get("/results").then((res) => setResults(res.data));
  }, []);

  return (
    <div className="card">
      <h2>📊 Cracking Results</h2>

      {results.length === 0 ? (
        <p>No hashes cracked yet.</p>
      ) : (
        <table border="1" cellPadding="6">
          <thead>
            <tr>
              <th>Hash</th>
              <th>Password</th>
              <th>Time (sec)</th>
              <th>Rules Used</th>
            </tr>
          </thead>
          <tbody>
            {results.map((r, i) => (
              <tr key={i}>
                <td>{r.hash.slice(0, 16)}...</td>
                <td>{r.password}</td>
                <td>{r.time}</td>
                <td>
                  {Object.entries(r.rules)
                    .filter(([_, v]) => v)
                    .map(([k]) => k)
                    .join(", ") || "None"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
