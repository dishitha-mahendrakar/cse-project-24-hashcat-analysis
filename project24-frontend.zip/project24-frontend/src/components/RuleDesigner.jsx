import { useState } from "react";
import api from "../services/api";

export default function RuleDesigner() {
  const [rules, setRules] = useState({
    capitalize: true,
    appendDigits: true,
    leetspeak: false,
  });

  const saveRules = async () => {
    await api.post("/save-rules", rules);
    alert("Rules saved on Kali Linux");
  };

  return (
    <div className="card">
      <h2>🧩 Rule Designer</h2>

      <label>
        <input
          type="checkbox"
          checked={rules.capitalize}
          onChange={(e) => setRules({ ...rules, capitalize: e.target.checked })}
        />
        Capitalize first letter
      </label>
      <br />

      <label>
        <input
          type="checkbox"
          checked={rules.appendDigits}
          onChange={(e) =>
            setRules({ ...rules, appendDigits: e.target.checked })
          }
        />
        Append digits
      </label>
      <br />

      <label>
        <input
          type="checkbox"
          checked={rules.leetspeak}
          onChange={(e) => setRules({ ...rules, leetspeak: e.target.checked })}
        />
        Leetspeak substitutions
      </label>
      <br />

      <button onClick={saveRules}>Save Rules</button>
    </div>
  );
}
